# ============================================
# Modo TEST: Exploración refinada de 50 ceros
# ============================================

import numpy as np
import pandas as pd
from mpmath import mp, mpf, sin, pi, log, zetazero
from tqdm import tqdm

# Configuración de precisión
mp.dps = 100  # Precisión decimal

# Parámetros de exploración
DELTA = mpf('0.000001')   # paso refinado
WINDOW = mpf('0.01')      # entorno reducido para alta precisión
N_CEROS = 50              # cantidad de ceros a validar
N = 90                    # tamaño del orbitador

# RD9 en precisión arbitraria
def RD9(x):
    s = sum(int(d) for d in str(abs(x)).replace('.', '') if d.isdigit())
    while s >= 10:
        s = sum(int(d) for d in str(s))
    return 9 if s == 0 else s

# Función ζRD refinada (orbitador simbólico)
def zeta_RD_mixed(t):
    base = [1, 2, 4, 5, 7, 8]
    orbit = [base[i % len(base)] for i in range(N)]
    return sum(RD9(sin(pi * t / mpf(k)) * log(k + 1)) for k in orbit)

# Exploración de ceros de la función zeta de Riemann
print("🔄 Generando los primeros", N_CEROS, "ceros de Riemann...")
ceros_riemann = [zetazero(n).imag for n in range(1, N_CEROS + 1)]

# Resultados
resultados = []

print("🔍 Escaneando entorno refinado de cada cero...")
for tn in tqdm(ceros_riemann):
    t0 = mpf(tn)
    t_range = [t0 - WINDOW + i * DELTA for i in range(int((2 * WINDOW) / DELTA))]

    z_vals = [zeta_RD_mixed(t) for t in t_range]
    min_idx = int(np.argmin(z_vals))
    t_star = t_range[min_idx]
    z_min = z_vals[min_idx]
    delta = abs(t_star - t0)

    resultados.append({
        't_n (real)': t0,
        't* (mínimo)': t_star,
        '|t* - t_n|': delta,
        'ζRD(t*)': z_min
    })

# Mostrar resumen
df = pd.DataFrame(resultados)
print("\n📈 Resultados del test refinado:")
print(df.to_string(index=False))

# Estadísticas generales
avg_error = df['|t* - t_n|'].mean()
max_error = df['|t* - t_n|'].max()
min_error = df['|t* - t_n|'].min()

print("\n📊 Estadísticas generales:")
print(f"🔹 Error promedio: {avg_error}")
print(f"🔸 Error máximo:   {max_error}")
print(f"🔸 Error mínimo:   {min_error}")
