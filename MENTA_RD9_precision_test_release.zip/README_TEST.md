# MENTA–RD₉ Precision Test

This script performs a high-precision structural validation of the first 50 Riemann zeros using the ζ_RD resonance function in arbitrary precision (`mpmath`, 100 digits).

## Script: `MENTA_RD9_precision_test.py`

### Features:
- Validates the first 50 non-trivial Riemann zeros
- Scans ±0.01 window with Δt = 0.000001
- Uses 90-element symbolic orbit for ζ_RD(t)
- Digital resonance via base-9 iterated digital sum (RD9)
- Outputs:
  - Real zero tₙ
  - Detected minimum t*
  - Absolute error |t* – tₙ|
  - Minimum ζ_RD(t*) value

### Performance:
- Up to 1.8 million evaluations per zero
- Runtime: ~90 seconds per zero (on standard CPU)

### Requirements:
- `mpmath`, `numpy`, `pandas`, `tqdm`

This is a deep scan meant for verification, not real-time use. Ideal for structural validation and visual analysis of ζ_RD performance at high precision.

