# MENTA–RD9 Structural Resonance Validator
# Detects Riemann zeros using digital resonance without evaluating ζ(s)

import numpy as np
import pandas as pd
from mpmath import zetazero, mp
from tqdm import tqdm
import os
import time

# 🎯 Configuration
mp.dps = 50                    # Precision
WINDOW = 0.01                  # Search window around t_n
DELTA_T = 0.001                # Step size for scanning
BLOCK_SIZE = 1000             # How many zeros per batch
EPSILON = 0.025                # Error threshold for structural validation

# 📁 Where to save the CSV result
SAVE_DIR = "zeta_RD_results"
os.makedirs(SAVE_DIR, exist_ok=True)

# 🎯 Which zeros to scan
start_index = 100_000_001
end_index = start_index + BLOCK_SIZE - 1

# 🔁 RD9 quantization function
def RD9(x):
    s = sum(int(d) for d in str(abs(x)).replace('.', '') if d.isdigit())
    while s >= 10:
        s = sum(int(d) for d in str(s))
    return 9 if s == 0 else s

# 📐 Structural RD9 function using t_n
def zeta_RD(t_values, tn_list):
    return [sum(RD9(np.sin(np.pi * t / tn)) for tn in tn_list) for t in t_values]

# 🧪 Main process
print(f"🔄 Validando ceros {start_index} a {end_index}...")
start_time = time.time()

# Load zeros from mpmath
zeros = [zetazero(n) for n in range(start_index, end_index + 1)]
t_n = [float(z.imag) for z in zeros]
block_results = []

print(f"✔️ {len(t_n)} ceros cargados.")
print(f"📌 Rango t_n: [{t_n[0]} , {t_n[-1]}]")

# Process each zero
for idx, tn in enumerate(tqdm(t_n, desc=f"  ▶ Ceros {start_index}-{end_index}")):
    if idx % 100 == 0:
        print(f"⏳ Procesando cero #{start_index + idx}...")

    t_values = np.arange(tn - WINDOW, tn + WINDOW, DELTA_T)
    zeta_vals = zeta_RD(t_values, t_n)
    min_idx = np.argmin(zeta_vals)
    t_star = t_values[min_idx]
    zeta_min = zeta_vals[min_idx]
    delta = abs(t_star - tn)

    block_results.append({
        "n": start_index + idx,
        "t_n (real)": round(tn, 8),
        "t* (mínimo)": round(t_star, 8),
        "|t* - t_n|": round(delta, 8),
        "ζRD(t*)": zeta_min
    })

# 📝 Save results
df = pd.DataFrame(block_results)
file_name = f"{SAVE_DIR}/zeta_RD_block_{start_index}_{end_index}_TURBO.csv"
df.to_csv(file_name, index=False)

# 📊 Statistics
avg = df["|t* - t_n|"].mean()
mx = df["|t* - t_n|"].max()
mn = df["|t* - t_n|"].min()

print(f"\n📊 Estadísticas bloque {start_index}-{end_index}:")
print(f"   🔹 Promedio: {avg:.8f}")
print(f"   🔸 Máximo:  {mx:.8f}")
print(f"   🔸 Mínimo:  {mn:.8f}")
print(f"💾 Guardado en: {file_name}")
print(f"⏱️ Tiempo total: {time.time() - start_time:.2f} segundos")
