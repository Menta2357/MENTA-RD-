# MENTA–RD₉ Validator TURBO

This script validates high-order zeros (n > 10⁸) of the Riemann zeta function using the MENTA–RD₉ model based on digital resonance.

## Files

- `MENTA_RD9_validator_TURBO.py`: main validation script
- `zeta_RD_block_100000001_100001000_TURBO.csv`: results for zeros 100M+1 to 100M+1000

## Results Summary

- Average error: 0.0126
- Maximum error: 0.0250
- 100% of zeros successfully detected with error < 0.05

## Description

The validator computes ζ_RD(t) using RD₉ digital resonance applied to a window around each zero tₙ. It detects the digital minimum (t*) that corresponds to each true zero.

All outputs are exported as CSV and suitable for further analysis or visualization.
