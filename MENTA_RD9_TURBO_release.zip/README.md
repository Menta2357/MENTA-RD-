# MENTA–RD₉ Validator TURBO

Este script valida ceros altos (n > 10⁸) de la función zeta de Riemann usando el modelo MENTA–RD₉ con resonancia digital.

## Archivos

- `MENTA_RD9_validator_TURBO.py`: script principal
- `zeta_RD_block_100000001_100001000_TURBO.csv`: resultados para los ceros 100M+1 a 100M+1000

## Resultados

- Error promedio: 0.0126
- Error máximo: 0.0250
- 100% de ceros localizados con error < 0.05
