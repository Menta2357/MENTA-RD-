import numpy as np
import pandas as pd
from mpmath import zetazero, mp
from tqdm import tqdm
import time
import os

mp.dps = 50
DELTA_T = 0.003
WINDOW = 0.025
BLOCK_SIZE = 1000

start_index = 100_000_000
end_index = start_index + BLOCK_SIZE
SAVE_DIR = "./"

os.makedirs(SAVE_DIR, exist_ok=True)

def RD9(x):
    s = sum(int(d) for d in str(abs(x)).replace('.', '') if d.isdigit())
    while s >= 10:
        s = sum(int(d) for d in str(s))
    return 9 if s == 0 else s

def zeta_RD(t_values, tn_list):
    return [sum(RD9(np.sin(np.pi / tn * t)) for tn in tn_list) for t in t_values]

print(f"🔄 Validando ceros {start_index + 1} a {end_index}...")
block_start = time.time()

zeros = [zetazero(n) for n in range(start_index + 1, end_index + 1)]
t_n = [float(z.imag) for z in zeros]
block_results = []

for idx, tn in enumerate(tqdm(t_n, desc=f'  ▶ Ceros {start_index+1}-{end_index}')):
    t_values = np.arange(tn - WINDOW, tn + WINDOW, DELTA_T)
    zeta_vals = zeta_RD(t_values, t_n)
    min_idx = np.argmin(zeta_vals)
    t_star = t_values[min_idx]
    zeta_min = zeta_vals[min_idx]
    delta = abs(t_star - tn)

    block_results.append({
        "n": start_index + idx + 1,
        "t_n (real)": round(tn, 8),
        "t* (mínimo)": round(t_star, 8),
        "|t* - t_n|": round(delta, 8),
        "ζRD(t*)": zeta_min
    })

df_block = pd.DataFrame(block_results)
file_name = f"{SAVE_DIR}/zeta_RD_block_{start_index+1:08d}_{end_index:08d}_TURBO.csv"
df_block.to_csv(file_name, index=False)

avg = df_block["|t* - t_n|"].mean()
mx = df_block["|t* - t_n|"].max()
mn = df_block["|t* - t_n|"].min()

print(f"📊 Promedio: {avg:.8f} | Máx: {mx:.8f} | Mín: {mn:.8f}")
print(f"💾 Guardado en: {file_name}")
print(f"⏱️ Tiempo total: {time.time() - block_start:.2f} s")
