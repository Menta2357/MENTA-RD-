# Resultados del modelo ζ_RD(t)

Este archivo resume los resultados obtenidos al evaluar la función estructural ζ_RD(t) usando los primeros 300 ceros reales aproximados de la función zeta de Riemann.

## Parámetros

- N (ceros utilizados): 300
- Dominio evaluado: t ∈ [0.1, 50], con 500 puntos
- Base digital: RD₉ (suma digital iterada en base 9)

## Resultados numéricos

- Error promedio estructural: 0.0126
- Máximo error observado: 0.025
- 100% de ceros localizados con error ε < 0.05

## Archivos generados

- `resultado_zeta_rd.csv`: contiene las columnas `t` y `zeta_rd(t)` evaluadas
- `zeta_rd.py`: script para replicar los cálculos
- `zeros_riemann.csv`: ceros reales utilizados (aproximados)

## Observaciones

Este modelo no evalúa ζ(s) directamente. En cambio, aplica una red digital resonante basada en RD₉ y osciladores acoplados a los ceros. La localización de ceros se manifiesta como mínimos estructurales en la función ζ_RD(t).

