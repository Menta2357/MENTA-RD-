import numpy as np
import pandas as pd

def cargar_ceros(path='zeros_riemann.csv'):
    """Carga los ceros reales desde un archivo CSV."""
    return pd.read_csv(path)['t'].values

def RD9(x):
    """Suma digital iterada en base 9."""
    val = int(abs(x) * 1e6)
    while val >= 10:
        val = sum(int(d) for d in str(val))
    return val % 9 or 9

def zeta_rd(t, ceros):
    """Función ζ_RD(t) como suma resonante digital."""
    return sum(RD9(np.sin(np.pi * t / tn)) for tn in ceros)

if __name__ == "__main__":
    ceros = cargar_ceros()
    dominio = np.linspace(0.1, 50, 500)
    resultados = [zeta_rd(t, ceros[:300]) for t in dominio]

    df = pd.DataFrame({'t': dominio, 'zeta_rd': resultados})
    df.to_csv("resultado_zeta_rd.csv", index=False)
    print("Cálculo completado. Resultados guardados en resultado_zeta_rd.csv")
